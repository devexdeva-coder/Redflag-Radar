export interface RedFlag {
  id: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  score: number;
  clause?: string;
  suggestion?: string;
}

export interface ScanResult {
  id: string;
  fileName: string;
  timestamp: number;
  overallRiskScore: number;
  redFlags: RedFlag[];
  summary: string;
}

export interface ComparisonCategory {
  category: string;
  contractA: {
    analysis: string;
    isWinner: boolean;
  };
  contractB: {
    analysis: string;
    isWinner: boolean;
  };
}

export interface ComparisonResult {
  id: string;
  fileNameA: string;
  fileNameB: string;
  timestamp: number;
  categories: ComparisonCategory[];
  verdict: {
    winner: 'A' | 'B' | 'Tie';
    explanation: string;
  };
}

export type ViewState = 'upload' | 'dashboard' | 'history' | 'comparison';

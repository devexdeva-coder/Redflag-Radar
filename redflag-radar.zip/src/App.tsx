import React, { useState, useEffect } from 'react';
import { FileUpload } from './components/FileUpload';
import { Dashboard } from './components/Dashboard';
import { HistoryView } from './components/HistoryView';
import { ComparisonView } from './components/ComparisonView';
import { ScanResult, RedFlag, ViewState, ComparisonResult } from './types';
import { Shield, Radar, Zap, Lock, Info, Clock, Plus, LogIn, LogOut, User as UserIcon, AlertCircle, Scale, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { TermsModal } from './components/TermsModal';
import { CustomCursor } from './components/CustomCursor';
import * as pdfjsLib from 'pdfjs-dist';
// @ts-ignore - Vite handles the ?url suffix for worker files
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';
import mammoth from 'mammoth';

// Set PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

import { 
  auth, 
  db, 
  googleProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User,
  collection,
  query,
  where,
  onSnapshot,
  doc,
  setDoc,
  deleteDoc,
  handleFirestoreError,
  OperationType
} from './firebase';

export default function App() {
  const [view, setView] = useState<ViewState>('upload');
  const [isScanning, setIsScanning] = useState(false);
  const [currentResult, setCurrentResult] = useState<ScanResult | null>(null);
  const [history, setHistory] = useState<ScanResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState({ 
    current: 0, 
    total: 0, 
    stage: '', 
    estimatedTime: 0 
  });
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [hasAcceptedTerms, setHasAcceptedTerms] = useState(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAuthReady(true);
      if (u) {
        setLoginError(null);
        // Sync user profile
        setDoc(doc(db, 'users', u.uid), {
          uid: u.uid,
          email: u.email,
          displayName: u.displayName,
          photoURL: u.photoURL,
          updatedAt: Date.now()
        }, { merge: true });
      } else {
        setHistory([]);
      }
    });
    return () => unsubscribe();
  }, []);

  // Firestore History Listener
  useEffect(() => {
    if (!user || !isAuthReady) return;

    const q = query(collection(db, 'scans'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const scans: ScanResult[] = [];
      snapshot.forEach((doc) => {
        scans.push(doc.data() as ScanResult);
      });
      setHistory(scans.sort((a, b) => b.timestamp - a.timestamp));
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'scans');
    });

    return () => unsubscribe();
  }, [user, isAuthReady]);

  const login = async () => {
    setLoginError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.error("Login failed", err);
      if (err.code === 'auth/popup-closed-by-user') {
        setLoginError("Sign-in was cancelled. Please try again.");
      } else if (err.code === 'auth/blocked-by-popup-blocker') {
        setLoginError("Sign-in popup was blocked by your browser. Please allow popups for this site.");
      } else {
        setLoginError("An error occurred during sign-in. Please try again.");
      }
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setView('upload');
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  const [isCompareMode, setIsCompareMode] = useState(false);
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult | null>(null);

  const scanFiles = async (files: File[]) => {
    if (!user) {
      setError("Please login to scan contracts.");
      return;
    }

    if (!hasAcceptedTerms) {
      setError("You must agree to the Terms of Service before scanning.");
      setIsTermsOpen(true);
      return;
    }

    if (isCompareMode && files.length !== 2) {
      setError("Please select exactly two contracts for comparison.");
      return;
    }

    setIsScanning(true);
    setError(null);
    setScanProgress({ current: 0, total: files.length, stage: 'Initializing Audit', estimatedTime: files.length * 15 });
    
    if (isCompareMode) {
      try {
        const texts = await Promise.all(files.map(async (file) => {
          let text = "";
          if (file.type === 'application/pdf') {
            const arrayBuffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            let fullText = "";
            for (let p = 1; p <= pdf.numPages; p++) {
              const page = await pdf.getPage(p);
              const content = await page.getTextContent();
              const strings = content.items.map((item: any) => item.str);
              fullText += strings.join(" ") + "\n";
            }
            text = fullText;
          } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
            const arrayBuffer = await file.arrayBuffer();
            const result = await mammoth.extractRawText({ arrayBuffer });
            text = result.value;
          } else {
            text = await file.text();
          }
          return text;
        }));

        setScanProgress(prev => ({ ...prev, stage: 'Neural Comparison Active' }));
        
        const response = await fetch("/api/compare", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ textA: texts[0], textB: texts[1] })
        });

        const responseText = await response.text();
        if (!response.ok) {
          throw new Error(responseText || "Comparison failed");
        }

        const data = JSON.parse(responseText);
        const compResult: ComparisonResult = {
          id: `comp-${Date.now()}`,
          fileNameA: files[0].name,
          fileNameB: files[1].name,
          timestamp: Date.now(),
          categories: data.categories,
          verdict: data.verdict
        };

        setComparisonResult(compResult);
        setView('comparison');
      } catch (err: any) {
        console.error("Comparison failed:", err);
        setError(err.message || "Failed to compare contracts.");
      } finally {
        setIsScanning(false);
      }
      return;
    }

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const remainingFiles = files.length - i;
      
      // Stage 1: Reading
      setScanProgress(prev => ({ 
        ...prev, 
        current: i + 1, 
        stage: `Reading ${file.name}`,
        estimatedTime: remainingFiles * 15
      }));
      await new Promise(r => setTimeout(r, 800));

      try {
        let text = "";
        
        if (file.type === 'application/pdf') {
          const arrayBuffer = await file.arrayBuffer();
          const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
          let fullText = "";
          for (let p = 1; p <= pdf.numPages; p++) {
            const page = await pdf.getPage(p);
            const content = await page.getTextContent();
            const strings = content.items.map((item: any) => item.str);
            fullText += strings.join(" ") + "\n";
          }
          text = fullText;
        } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
          const arrayBuffer = await file.arrayBuffer();
          const result = await mammoth.extractRawText({ arrayBuffer });
          text = result.value;
        } else {
          text = await file.text();
        }

        if (!text || text.trim().length < 10) {
          throw new Error(`Could not extract sufficient text from ${file.name}. Please ensure it's not empty or an image-only PDF.`);
        }
        
        // Stage 2: Neural Analysis
        setScanProgress(prev => ({ ...prev, stage: 'Neural Analysis Active' }));
        
        const response = await fetch("/api/scan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text })
        });

        const responseText = await response.text();
        if (!response.ok) {
          let errorMsg = "Server error during analysis";
          try {
            const errorData = JSON.parse(responseText);
            // Handle OpenRouter's nested error structure or a flat error string
            if (typeof errorData.error === 'object' && errorData.error.message) {
              errorMsg = errorData.error.message;
            } else {
              errorMsg = errorData.error || errorData.message || errorMsg;
            }
          } catch (e) {
            errorMsg = responseText || `Status ${response.status}: ${errorMsg}`;
          }
          throw new Error(errorMsg);
        }

        let data;
        try {
          data = JSON.parse(responseText);
        } catch (e) {
          console.error("Failed to parse scan response:", responseText);
          throw new Error(`Analysis engine returned invalid data for ${file.name}.`);
        }
        
        // Stage 3: Generating Report
        setScanProgress(prev => ({ ...prev, stage: 'Generating Intelligence Report' }));
        await new Promise(r => setTimeout(r, 1200));

        const scanId = `scan-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        const result: ScanResult = {
          id: scanId,
          fileName: file.name,
          timestamp: Date.now(),
          overallRiskScore: data.overallRiskScore || 0,
          summary: data.summary || "No summary provided.",
          redFlags: (data.redFlags || []).map((f: any, i: number) => ({
            ...f,
            id: `flag-${i}`
          }))
        };
        
        // Save to Firestore
        await setDoc(doc(db, 'scans', scanId), {
          ...result,
          userId: user.uid
        });
        
        if (i === 0) {
          setCurrentResult(result);
          setView('dashboard');
        }
      } catch (err: any) {
        console.error(`Scan failed for ${file.name}:`, err);
        const errorMessage = err.message || "Unknown analysis error";
        const formattedError = errorMessage.startsWith("Scan failed for") 
          ? errorMessage 
          : `Scan failed for ${file.name}: ${errorMessage}`;
        setError(prev => (prev ? `${prev}\n` : "") + formattedError);
      }
    }
    
    setIsScanning(false);
  };

  const deleteHistoryItem = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'scans', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `scans/${id}`);
    }
  };

  const updateSummary = async (newSummary: string) => {
    if (!currentResult || !user) return;
    
    try {
      await setDoc(doc(db, 'scans', currentResult.id), {
        summary: newSummary
      }, { merge: true });
      
      setCurrentResult(prev => prev ? { ...prev, summary: newSummary } : null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `scans/${currentResult.id}`);
    }
  };

  const selectHistoryItem = (item: ScanResult) => {
    setCurrentResult(item);
    setView('dashboard');
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-primary selection:text-black overflow-x-hidden legal-grid atmosphere">
      <CustomCursor />
      {/* Ambient Background Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="stars" />
        <div className="scan-line opacity-20" />
        <div className="data-stream opacity-10" style={{ right: '10%' }} />
        <div className="data-stream opacity-10" style={{ left: '5%', animationDelay: '2s' }} />
        
        <motion.div 
          animate={{ 
            scale: [1, 1.05, 1],
            opacity: [0.1, 0.15, 0.1],
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -top-[20%] -left-[10%] w-[80%] h-[80%] bg-primary/5 blur-[160px] rounded-full" 
        />
      </div>

      {/* Header */}
      <header className="relative z-50 border-b border-white/5 bg-black/40 backdrop-blur-xl sticky top-0">
        <div className="max-w-7xl mx-auto px-6 h-24 flex items-center justify-between">
          <div className="flex items-center gap-4 cursor-pointer group" onClick={() => setView('upload')}>
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center group-hover:rotate-12 transition-transform duration-500 shadow-[0_0_30px_rgba(255,255,255,0.2)]">
              <Radar className="w-7 h-7 text-black" />
            </div>
            <div>
              <h1 className="text-2xl font-hero tracking-wider uppercase">REDFLAG RADAR</h1>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <p className="text-[10px] uppercase tracking-[0.3em] text-white/40 font-bold">Intelligence System v2.0</p>
              </div>
            </div>
          </div>
          
          <nav className="flex items-center gap-4 md:gap-10">
            {user ? (
              <>
                <button 
                  onClick={() => setView('upload')}
                  className={cn(
                    "flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] transition-all relative py-2",
                    view === 'upload' ? "text-primary" : "text-white/40 hover:text-white"
                  )}
                >
                  <Plus className="w-4 h-4" />
                  <span className="hidden sm:inline">New Scan</span>
                  {view === 'upload' && <motion.div layoutId="nav-active" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
                </button>
                <button 
                  onClick={() => setView('history')}
                  className={cn(
                    "flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] transition-all relative py-2",
                    view === 'history' ? "text-primary" : "text-white/40 hover:text-white"
                  )}
                >
                  <Clock className="w-4 h-4" />
                  <span className="hidden sm:inline">History</span>
                  {view === 'history' && <motion.div layoutId="nav-active" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
                </button>
                <div className="h-8 w-px bg-white/10" />
                <div className="flex items-center gap-4">
                  <div className="text-right hidden sm:block">
                    <p className="text-xs font-bold text-white/90 leading-none mb-1">{user.displayName}</p>
                    <button onClick={logout} className="text-[9px] uppercase tracking-widest text-white/30 hover:text-primary transition-colors">Sign Out</button>
                  </div>
                  <div className="relative group">
                    <div className="absolute -inset-1 bg-primary/20 rounded-xl blur opacity-0 group-hover:opacity-100 transition-opacity" />
                    {user.photoURL ? (
                      <img src={user.photoURL} alt="" className="relative w-10 h-10 rounded-xl border border-white/10 object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="relative w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                        <UserIcon className="w-5 h-5 text-white/40" />
                      </div>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <button 
                onClick={login}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-black text-[10px] font-bold uppercase tracking-[0.2em] hover:bg-primary hover:shadow-[0_0_30px_rgba(242,125,38,0.4)] transition-all active:scale-95"
              >
                <LogIn className="w-4 h-4" />
                Sign In
              </button>
            )}
          </nav>
        </div>
      </header>

      <main className="relative z-10 pt-20 px-6 pb-20">
        <AnimatePresence mode="wait">
          {!user && isAuthReady && (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-6xl mx-auto text-center space-y-24 py-32 perspective-2000"
            >
              <motion.div 
                initial={{ rotateX: 20, opacity: 0, y: 40 }}
                animate={{ rotateX: 0, opacity: 1, y: 0 }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
                className="space-y-12 preserve-3d"
              >
                <div className="overflow-hidden">
                  <motion.h2 
                    initial={{ y: "100%" }}
                    animate={{ y: 0 }}
                    transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
                    className="text-[12vw] md:text-[10vw] font-hero leading-[0.75] tracking-tighter uppercase text-glow mb-4"
                  >
                    REDFLAG <br />
                    <span className="text-white/5 italic">RADAR.</span>
                  </motion.h2>
                </div>
                
                <motion.p 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.5 }}
                  className="text-2xl md:text-4xl text-white/20 max-w-5xl mx-auto font-light leading-tight tracking-tight italic"
                >
                  The definitive AI contract audit engine. <br className="hidden md:block" />
                  Engineered for precision. Built for speed.
                </motion.p>
              </motion.div>

              <div className="flex flex-col items-center gap-16">
                {loginError && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-5 rounded-2xl bg-red-500/5 border border-red-500/10 text-red-400/60 text-sm max-w-md mx-auto flex items-center gap-4 backdrop-blur-md"
                  >
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    {loginError}
                  </motion.div>
                )}

                <motion.button 
                  initial={{ opacity: 0, y: 20, rotateX: 10 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0 }}
                  transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.8 }}
                  onClick={login}
                  whileHover={{ scale: 1.05, y: -5, rotateX: -5 }}
                  whileTap={{ scale: 0.98 }}
                  className="group relative px-20 py-8 rounded-[2rem] bg-white text-black text-2xl font-hero tracking-[0.2em] uppercase overflow-hidden transition-all shadow-[0_40px_80px_rgba(255,255,255,0.05)]"
                >
                  <div className="absolute inset-0 bg-primary translate-y-full group-hover:translate-y-0 transition-transform duration-700 ease-[0.16, 1, 0.3, 1]" />
                  <span className="relative z-10 group-hover:text-white transition-colors duration-500">Launch Radar</span>
                </motion.button>
              </div>
            </motion.div>
          )}

          {user && view === 'upload' && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              className="max-w-4xl mx-auto space-y-16"
            >
              <div className="text-center space-y-6">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold uppercase tracking-[0.3em]"
                >
                  <Zap className="w-4 h-4" />
                  Neural Analysis Active
                </motion.div>
                <h2 className="text-6xl md:text-8xl font-hero tracking-tighter uppercase leading-[0.85]">
                  {isCompareMode ? 'NEURAL' : 'DROP YOUR'} <br />
                  <span className="text-white/20 italic">{isCompareMode ? 'BATTLE.' : 'CONTRACTS.'}</span>
                </h2>
                <p className="text-xl text-white/40 max-w-xl mx-auto font-light">
                  {isCompareMode ? 'Compare two contracts head-to-head for the ultimate safety audit.' : 'Secure multi-file analysis. Drag and drop PDF or text files to begin the audit.'}
                </p>

                {/* Compare Mode Toggle */}
                <div className="flex justify-center pt-8">
                  <div className="p-1 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-1">
                    <button
                      onClick={() => setIsCompareMode(false)}
                      className={cn(
                        "px-6 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all",
                        !isCompareMode ? "bg-white text-black shadow-xl" : "text-white/40 hover:text-white"
                      )}
                    >
                      Single Scan
                    </button>
                    <button
                      onClick={() => setIsCompareMode(true)}
                      className={cn(
                        "px-6 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all",
                        isCompareMode ? "bg-primary text-white shadow-[0_0_20px_rgba(242,125,38,0.3)]" : "text-white/40 hover:text-white"
                      )}
                    >
                      Compare Mode
                    </button>
                  </div>
                </div>
              </div>
              
                <div className="relative group">
                  <div className="absolute -inset-1 bg-primary/10 rounded-[2rem] blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
                  <div className="relative glass-panel rounded-[2rem] p-4">
                    <FileUpload onFilesSelect={scanFiles} isScanning={isScanning} progress={scanProgress} isCompareMode={isCompareMode} />
                  </div>
                </div>
              
              <div className="flex flex-col items-center gap-8">
                <div className="flex items-center gap-4 p-5 rounded-2xl bg-white/[0.02] border border-white/5 backdrop-blur-md">
                  <div className="relative w-5 h-5">
                    <input 
                      type="checkbox" 
                      id="terms" 
                      checked={hasAcceptedTerms}
                      onChange={(e) => setHasAcceptedTerms(e.target.checked)}
                      className="peer absolute inset-0 opacity-0 cursor-pointer z-10"
                    />
                    <div className="absolute inset-0 rounded border border-white/20 bg-white/5 peer-checked:bg-primary peer-checked:border-primary transition-all flex items-center justify-center">
                      <motion.div 
                        initial={false}
                        animate={{ scale: hasAcceptedTerms ? 1 : 0 }}
                        className="w-3 h-3 bg-white rounded-[1px]" 
                      />
                    </div>
                  </div>
                  <label htmlFor="terms" className="text-[11px] font-bold uppercase tracking-widest text-white/30 cursor-pointer select-none">
                    I agree to the <button onClick={() => setIsTermsOpen(true)} className="text-white hover:text-primary underline underline-offset-4 transition-colors">Terms of Service</button>
                  </label>
                </div>

                {isScanning && (
                  <div className="w-full max-w-md space-y-4">
                    <div className="flex justify-between text-[10px] uppercase tracking-[0.3em] font-bold text-white/40">
                      <span className="flex items-center gap-2">
                        <motion.div 
                          animate={{ rotate: 360 }}
                          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                        >
                          <Radar className="w-3 h-3" />
                        </motion.div>
                        Analyzing Document
                      </span>
                      <span>{scanProgress.current} / {scanProgress.total}</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-primary shadow-[0_0_20px_rgba(242,125,38,0.5)]"
                        initial={{ width: 0 }}
                        animate={{ width: `${(scanProgress.current / scanProgress.total) * 100}%` }}
                      />
                    </div>
                  </div>
                )}

                {error && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-5 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-4 backdrop-blur-md max-w-xl"
                  >
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    <p className="whitespace-pre-line leading-relaxed">{error}</p>
                  </motion.div>
                )}
              </div>
            </motion.div>
          )}

          {view === 'dashboard' && currentResult && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-7xl mx-auto space-y-12"
            >
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
                <div className="space-y-4">
                  <button 
                    onClick={() => setView('history')}
                    className="group flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.3em] text-white/30 hover:text-primary transition-colors"
                  >
                    <motion.span 
                      animate={{ x: [0, -4, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      ←
                    </motion.span>
                    Back to History
                  </button>
                  <h2 className="text-5xl font-hero tracking-tighter uppercase leading-none">
                    AUDIT REPORT <br />
                    <span className="text-white/20 italic text-3xl">{currentResult.fileName}</span>
                  </h2>
                </div>
                <div className="flex items-center gap-4 px-6 py-4 rounded-2xl glass-panel">
                  <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/60">Verification Complete</span>
                </div>
              </div>

              <Dashboard result={currentResult} onUpdateSummary={updateSummary} />
            </motion.div>
          )}

          {view === 'comparison' && comparisonResult && (
            <motion.div
              key="comparison"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-7xl mx-auto"
            >
              <ComparisonView 
                result={comparisonResult} 
                onBack={() => setView('upload')}
              />
            </motion.div>
          )}

          {view === 'history' && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-7xl mx-auto"
            >
              <div className="mb-12 space-y-4">
                <h2 className="text-5xl font-hero tracking-tighter uppercase">SCAN HISTORY</h2>
                <p className="text-white/40 font-light text-lg">Your secure archive of analyzed legal documents.</p>
              </div>
              <HistoryView 
                history={history} 
                onSelectItem={selectHistoryItem}
                onDeleteItem={deleteHistoryItem}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-24 px-6 border-t border-white/5 mt-20">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="flex flex-col items-center md:items-start gap-6">
            <div className="flex items-center gap-3">
              <Radar className="w-8 h-8 text-primary" />
              <span className="text-2xl font-hero tracking-[0.2em] uppercase">REDFLAG RADAR</span>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/20">
                Advanced Contract Intelligence &copy; 2026
              </p>
              <div className="flex items-center gap-2 pt-2">
                <span className="text-[9px] uppercase tracking-widest text-white/10 font-bold">Developed by</span>
                <a 
                  href="https://www.linkedin.com/in/divyansh-sharma-0a1b8538b/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="group flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-primary transition-all"
                >
                  Divyansh Sharma
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          </div>
          <div className="flex flex-wrap justify-center gap-16">
            <div className="space-y-6">
              <h5 className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/40 border-b border-white/5 pb-2">Legal</h5>
              <div className="flex flex-col gap-3">
                <button onClick={() => setIsTermsOpen(true)} className="text-[10px] font-bold uppercase tracking-widest text-white/20 hover:text-primary transition-colors text-left">Terms of Service</button>
                <button className="text-[10px] font-bold uppercase tracking-widest text-white/20 hover:text-primary transition-colors text-left">Privacy Policy</button>
              </div>
            </div>
            <div className="space-y-6">
              <h5 className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/40 border-b border-white/5 pb-2">Resources</h5>
              <div className="flex flex-col gap-3">
                <button className="text-[10px] font-bold uppercase tracking-widest text-white/20 hover:text-primary transition-colors text-left">API Documentation</button>
                <button className="text-[10px] font-bold uppercase tracking-widest text-white/20 hover:text-primary transition-colors text-left">Support Center</button>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <TermsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />
    </div>
  );
}

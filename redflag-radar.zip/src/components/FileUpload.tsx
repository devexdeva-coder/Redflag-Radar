import React, { useCallback, useState, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, X, Loader2, ShieldCheck, Zap, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface FileUploadProps {
  onFilesSelect: (files: File[]) => void;
  isScanning: boolean;
  isCompareMode?: boolean;
  progress?: {
    current: number;
    total: number;
    stage: string;
    estimatedTime: number;
  };
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFilesSelect, isScanning, progress, isCompareMode }) => {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isHovered, setIsHovered] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      if (isCompareMode) {
        // In compare mode, we only want up to 2 files
        setSelectedFiles(prev => {
          const newFiles = [...prev, ...acceptedFiles].slice(0, 2);
          onFilesSelect(newFiles);
          return newFiles;
        });
      } else {
        setSelectedFiles(prev => [...prev, ...acceptedFiles]);
        onFilesSelect(acceptedFiles);
      }
    }
  }, [onFilesSelect, isCompareMode]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    multiple: true,
    disabled: isScanning
  } as any);

  const clearFiles = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedFiles([]);
  };

  return (
    <div className="w-full max-w-4xl mx-auto perspective-2000">
      <motion.div
        {...getRootProps()}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        animate={{
          rotateX: isDragActive ? 5 : isHovered ? 2 : 0,
          scale: isDragActive ? 1.02 : 1,
        }}
        className={cn(
          "relative group cursor-pointer rounded-[2.5rem] border border-white/5 transition-all duration-500 p-16 text-center preserve-3d overflow-hidden",
          isDragActive ? "bg-white/[0.05] border-primary/40 shadow-[0_0_80px_rgba(242,125,38,0.1)]" : "bg-white/[0.02] hover:bg-white/[0.04] shadow-2xl",
          isScanning && "cursor-not-allowed"
        )}
      >
        <input {...getInputProps()} />
        
        {/* Background Glow */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
        
        <AnimatePresence mode="wait">
          {isScanning ? (
            <motion.div
              key="scanning"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              className="relative z-10 flex flex-col items-center gap-8"
            >
              <div className="relative">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                  className="w-32 h-32 rounded-full border-2 border-primary/20 border-t-primary shadow-[0_0_40px_rgba(242,125,38,0.2)]"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Zap className="w-10 h-10 text-primary animate-pulse" />
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-3xl font-hero tracking-tighter uppercase text-glow">
                  {progress?.stage || "Analyzing Intelligence"}
                </h3>
                <div className="flex flex-col items-center gap-2">
                  <div className="w-64 h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(progress?.current || 0) / (progress?.total || 1) * 100}%` }}
                      className="h-full bg-primary shadow-[0_0_15px_rgba(242,125,38,0.5)]"
                    />
                  </div>
                  <div className="flex justify-between w-64 text-[10px] font-bold uppercase tracking-widest text-white/20">
                    <span>File {progress?.current} of {progress?.total}</span>
                    <span>Est. {progress?.estimatedTime || 0}s remaining</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : selectedFiles.length > 0 ? (
            <motion.div
              key="selected"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative z-10 flex flex-col items-center gap-8 w-full"
            >
              {isCompareMode ? (
                <div className="grid grid-cols-2 gap-8 w-full max-w-2xl">
                  <div className="p-8 rounded-[2rem] bg-white/[0.03] border border-white/10 flex flex-col items-center gap-4">
                    <div className="p-4 rounded-2xl bg-primary/10 text-primary">
                      <FileText className="w-8 h-8" />
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] font-bold uppercase tracking-widest text-white/20 mb-1">Contract A</p>
                      <p className="text-sm font-medium truncate max-w-[150px]">{selectedFiles[0]?.name || "Empty"}</p>
                    </div>
                  </div>
                  <div className="p-8 rounded-[2rem] bg-white/[0.03] border border-white/10 flex flex-col items-center gap-4">
                    <div className="p-4 rounded-2xl bg-primary/10 text-primary">
                      <FileText className="w-8 h-8" />
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] font-bold uppercase tracking-widest text-white/20 mb-1">Contract B</p>
                      <p className="text-sm font-medium truncate max-w-[150px]">{selectedFiles[1]?.name || "Empty"}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-6 rounded-[2rem] bg-primary/10 border border-primary/20 shadow-[0_0_40px_rgba(242,125,38,0.1)]">
                  <FileText className="w-16 h-16 text-primary" />
                </div>
              )}
              
              <div className="space-y-2">
                <p className="text-3xl font-hero tracking-tighter uppercase">
                  {isCompareMode ? (selectedFiles.length === 2 ? 'Battle Ready' : 'Need 2 Contracts') : `${selectedFiles.length} ${selectedFiles.length === 1 ? 'Contract' : 'Contracts'} Ready`}
                </p>
                {!isCompareMode && (
                  <p className="text-sm text-white/30 font-light max-w-md mx-auto">
                    {selectedFiles.map(f => f.name).join(', ')}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-6">
                <button
                  onClick={clearFiles}
                  className="px-8 py-3 rounded-xl bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-white hover:bg-white/10 transition-all"
                >
                  Reset
                </button>
                <div className={cn(
                  "px-8 py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest shadow-[0_0_30px_rgba(242,125,38,0.3)] transition-all",
                  isCompareMode && selectedFiles.length < 2 ? "bg-white/5 text-white/20 cursor-not-allowed" : "bg-primary text-white cursor-pointer"
                )}>
                  {isCompareMode ? 'Start Battle' : 'Start Audit'}
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="idle"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="relative z-10 flex flex-col items-center gap-8"
            >
              <div className="relative group-hover:scale-110 transition-transform duration-500">
                <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="relative p-8 rounded-[2.5rem] bg-white/[0.03] border border-white/10 group-hover:border-primary/40 transition-colors">
                  <Upload className="w-16 h-16 text-white/20 group-hover:text-primary transition-colors duration-500" />
                </div>
              </div>
              <div className="space-y-3">
                <h3 className="text-4xl font-hero tracking-tighter uppercase">
                  {isCompareMode ? 'Neural' : 'Secure'} <span className="text-white/20 italic">{isCompareMode ? 'Battle.' : 'Upload.'}</span>
                </h3>
                <p className="text-sm text-white/30 font-light max-w-xs mx-auto leading-relaxed">
                  {isCompareMode ? 'Drop two contracts side-by-side to compare their safety.' : 'Drag and drop your legal documents here for neural analysis.'}
                </p>
              </div>
              <div className="px-10 py-4 rounded-2xl bg-white text-black text-xs font-bold uppercase tracking-[0.2em] shadow-2xl group-hover:bg-primary group-hover:text-white transition-all duration-500">
                {isCompareMode ? 'Select Both Contracts' : 'Select Documents'}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Decorative Elements */}
        <div className="absolute top-0 left-0 w-20 h-20 border-t-2 border-l-2 border-white/5 rounded-tl-[2.5rem]" />
        <div className="absolute bottom-0 right-0 w-20 h-20 border-b-2 border-r-2 border-white/5 rounded-br-[2.5rem]" />
      </motion.div>
      
      {/* Trust Badges */}
      <div className="mt-12 flex justify-center gap-12 opacity-30 grayscale hover:grayscale-0 transition-all duration-700">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4" />
          <span className="text-[9px] font-bold uppercase tracking-widest">AES-256 Encrypted</span>
        </div>
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4" />
          <span className="text-[9px] font-bold uppercase tracking-widest">Neural Processing</span>
        </div>
        <div className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4" />
          <span className="text-[9px] font-bold uppercase tracking-widest">Zero Retention</span>
        </div>
      </div>
    </div>
  );
};

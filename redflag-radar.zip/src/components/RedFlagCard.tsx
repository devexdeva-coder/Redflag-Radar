import React from 'react';
import { AlertTriangle, ShieldAlert, Info, CheckCircle2, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { RedFlag } from '@/src/types';
import { cn } from '@/src/lib/utils';

interface RedFlagCardProps {
  flag: RedFlag;
  index: number;
}

const severityConfig = {
  low: { icon: Info, color: 'text-blue-400', bg: 'bg-blue-400/10', border: 'border-blue-400/20' },
  medium: { icon: AlertTriangle, color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/20' },
  high: { icon: ShieldAlert, color: 'text-orange-400', bg: 'bg-orange-400/10', border: 'border-orange-400/20' },
  critical: { icon: ShieldAlert, color: 'text-red-500', bg: 'bg-red-500/10', border: 'border-red-500/20' },
};

export const RedFlagCard: React.FC<RedFlagCardProps> = ({ flag, index }) => {
  const config = severityConfig[flag.severity];
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -8, scale: 1.02 }}
      className="glass-panel p-8 rounded-[2rem] flex flex-col gap-6 group transition-all duration-500 h-full"
    >
      <div className="flex items-start justify-between">
        <div className={cn("p-4 rounded-2xl", config.bg, "border", config.border)}>
          <Icon className={cn("w-6 h-6", config.color)} />
        </div>
        <div className="text-right">
          <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/20">Risk Score</span>
          <p className={cn("text-3xl font-hero tracking-tighter", config.color)}>{flag.score}</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className={cn("w-1.5 h-1.5 rounded-full", config.color)} />
          <h3 className="text-sm font-bold uppercase tracking-widest text-white/90 group-hover:text-primary transition-colors">{flag.title}</h3>
        </div>
        <p className="text-xs text-white/40 leading-relaxed font-light line-clamp-3 group-hover:text-white/60 transition-colors">
          {flag.description}
        </p>
      </div>

      {flag.clause && (
        <div className="p-4 rounded-2xl bg-black/40 border border-white/5 group-hover:border-white/10 transition-colors">
          <p className="text-[9px] uppercase tracking-[0.3em] text-white/20 mb-2 font-bold">Detected Clause</p>
          <p className="text-[11px] font-mono italic text-white/40 leading-relaxed group-hover:text-white/60 transition-colors">
            "{flag.clause}"
          </p>
        </div>
      )}

      <div className="mt-auto pt-6 border-t border-white/5 space-y-4">
        {flag.suggestion && (
          <div className="flex flex-col gap-2">
            <span className="text-[9px] font-bold uppercase tracking-[0.3em] text-white/20">Recommendation</span>
            <p className="text-[11px] text-white/60 font-medium italic leading-relaxed">
              "{flag.suggestion}"
            </p>
          </div>
        )}
        
        <button className="flex items-center gap-2 text-[9px] font-bold uppercase tracking-[0.4em] text-primary opacity-0 group-hover:opacity-100 transition-all translate-x-[-10px] group-hover:translate-x-0">
          View Details <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </motion.div>
  );
};

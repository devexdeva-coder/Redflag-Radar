import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ScanResult, RedFlag } from '@/src/types';
import { RedFlagCard } from './RedFlagCard';
import { Shield, AlertCircle, FileText, Activity, Download, ArrowUpDown, RefreshCw, Loader2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface DashboardProps {
  result: ScanResult;
  onUpdateSummary?: (newSummary: string) => void;
}

type SortField = 'score' | 'severity';
type SortOrder = 'asc' | 'desc';

const severityWeight = {
  critical: 4,
  high: 3,
  medium: 2,
  low: 1
};

export const Dashboard: React.FC<DashboardProps> = ({ result, onUpdateSummary }) => {
  const [sortBy, setSortBy] = useState<SortField>('severity');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [isRegenerating, setIsRegenerating] = useState(false);

  const sortedFlags = useMemo(() => {
    return [...result.redFlags].sort((a, b) => {
      let valA = sortBy === 'severity' ? severityWeight[a.severity] : a.score;
      let valB = sortBy === 'severity' ? severityWeight[b.severity] : b.score;
      
      if (sortOrder === 'asc') return valA - valB;
      return valB - valA;
    });
  }, [result.redFlags, sortBy, sortOrder]);

  const regenerateSummary = async () => {
    setIsRegenerating(true);
    try {
      const response = await fetch("/api/regenerate-summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          redFlags: result.redFlags,
          currentSummary: result.summary 
        })
      });
      const data = await response.json();
      if (data.summary && onUpdateSummary) {
        onUpdateSummary(data.summary);
      }
    } catch (err) {
      console.error("Failed to regenerate summary", err);
    } finally {
      setIsRegenerating(false);
    }
  };

  const getRiskColor = (score: number) => {
    if (score < 30) return 'text-green-400';
    if (score < 60) return 'text-yellow-400';
    if (score < 85) return 'text-orange-400';
    return 'text-red-500';
  };

  const exportAsJSON = () => {
    const dataStr = JSON.stringify(result, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `redflag_radar_${result.fileName.replace(/\s+/g, '_')}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const exportAsCSV = () => {
    const headers = ['Title', 'Severity', 'Score', 'Description', 'Clause', 'Suggestion'];
    const rows = result.redFlags.map(f => [
      `"${f.title.replace(/"/g, '""')}"`,
      f.severity,
      f.score,
      `"${f.description.replace(/"/g, '""')}"`,
      `"${(f.clause || '').replace(/"/g, '""')}"`,
      `"${(f.suggestion || '').replace(/"/g, '""')}"`
    ]);
    
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `redflag_radar_${result.fileName.replace(/\s+/g, '_')}.csv`);
    link.click();
  };

  return (
    <div className="space-y-12">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel p-10 rounded-[2.5rem] space-y-6 relative overflow-hidden group"
        >
          <div className="flex items-center justify-between relative z-10">
            <Activity className="w-8 h-8 text-primary" />
            <span className="text-[10px] font-bold uppercase tracking-[0.5em] text-white/20">Risk Index</span>
          </div>
          <div className="flex items-baseline gap-3 relative z-10">
            <span className={cn("text-8xl font-hero tracking-tighter", getRiskColor(result.overallRiskScore))}>{result.overallRiskScore}</span>
            <span className="text-2xl text-white/10 font-hero">%</span>
          </div>
          <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden relative z-10">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${result.overallRiskScore}%` }}
              className={cn(
                "h-full transition-colors duration-1000 shadow-[0_0_20px_rgba(242,125,38,0.3)]",
                result.overallRiskScore > 70 ? "bg-red-500" : result.overallRiskScore > 40 ? "bg-yellow-500" : "bg-green-500"
              )}
            />
          </div>
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-primary/5 blur-[80px] rounded-full group-hover:bg-primary/10 transition-colors" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-panel p-8 rounded-[2rem] space-y-4"
        >
          <div className="flex items-center justify-between">
            <AlertCircle className="w-6 h-6 text-red-500" />
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/20">Red Flags</span>
          </div>
          <span className="text-6xl font-hero tracking-tighter block">{result.redFlags.length}</span>
          <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Detected Issues</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-panel p-8 rounded-[2rem] space-y-4 md:col-span-2 relative overflow-hidden group"
        >
          <div className="relative z-10 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileText className="w-6 h-6 text-white/40" />
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/20">Executive Summary</span>
              </div>
              <button 
                onClick={regenerateSummary}
                disabled={isRegenerating}
                className="p-2 rounded-xl hover:bg-white/5 text-white/40 hover:text-primary transition-all active:scale-90 disabled:opacity-50"
                title="Regenerate Summary"
              >
                {isRegenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-sm text-white/60 leading-relaxed font-light italic">
              "{result.summary}"
            </p>
          </div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2 group-hover:bg-primary/10 transition-colors" />
        </motion.div>
      </div>

      {/* Controls Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-6 rounded-[2rem] glass-panel backdrop-blur-xl">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="flex items-center gap-4">
            <Shield className="w-8 h-8 text-primary" />
            <h2 className="text-2xl font-hero tracking-widest uppercase">Detected Red Flags</h2>
          </div>
          
          <div className="h-10 w-px bg-white/10 hidden md:block" />
          
          <div className="flex items-center gap-4">
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/40">Sort by:</span>
            <div className="flex bg-black/40 rounded-2xl p-1.5 border border-white/5">
              <button
                onClick={() => {
                  if (sortBy === 'severity') setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
                  else { setSortBy('severity'); setSortOrder('desc'); }
                }}
                className={cn(
                  "px-6 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-[0.2em] transition-all flex items-center gap-2",
                  sortBy === 'severity' ? "bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.1)]" : "text-white/40 hover:text-white"
                )}
              >
                Severity
                {sortBy === 'severity' && <ArrowUpDown className="w-3 h-3" />}
              </button>
              <button
                onClick={() => {
                  if (sortBy === 'score') setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
                  else { setSortBy('score'); setSortOrder('desc'); }
                }}
                className={cn(
                  "px-6 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-[0.2em] transition-all flex items-center gap-2",
                  sortBy === 'score' ? "bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.1)]" : "text-white/40 hover:text-white"
                )}
              >
                Risk Score
                {sortBy === 'score' && <ArrowUpDown className="w-3 h-3" />}
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={exportAsJSON}
            className="flex items-center gap-3 px-6 py-3.5 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-[0.3em] text-white/60 hover:bg-white hover:text-black transition-all active:scale-95"
          >
            <Download className="w-4 h-4" />
            JSON
          </button>
          <button
            onClick={exportAsCSV}
            className="flex items-center gap-3 px-6 py-3.5 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-[0.3em] text-white/60 hover:bg-white hover:text-black transition-all active:scale-95"
          >
            <Download className="w-4 h-4" />
            CSV
          </button>
        </div>
      </div>

      {/* Flags Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <AnimatePresence mode="popLayout">
          {sortedFlags.map((flag, index) => (
            <RedFlagCard key={flag.id} flag={flag} index={index} />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

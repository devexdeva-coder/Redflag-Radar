import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShieldCheck, FileText, Scale, Lock, AlertCircle } from 'lucide-react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TermsModal: React.FC<TermsModalProps> = ({ isOpen, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-2xl max-h-[80vh] overflow-hidden bg-zinc-900 border border-white/10 rounded-3xl shadow-2xl flex flex-col"
          >
            <div className="p-6 border-bottom border-white/5 flex items-center justify-between bg-zinc-900/50 backdrop-blur-md sticky top-0 z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/20">
                  <Scale className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white tracking-tight">Terms of Service</h3>
                  <p className="text-[10px] uppercase tracking-widest text-white/40 font-bold">Last Updated: April 1, 2026</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full hover:bg-white/5 text-white/40 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-6 text-sm text-white/60 leading-relaxed custom-scrollbar">
              <section className="space-y-3">
                <h4 className="text-white font-bold flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-primary" />
                  1. Acceptance of Terms
                </h4>
                <p>
                  By accessing and using RedFlag Radar ("the Service"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the Service.
                </p>
              </section>

              <section className="space-y-3">
                <h4 className="text-white font-bold flex items-center gap-2">
                  <FileText className="w-4 h-4 text-primary" />
                  2. Nature of Service
                </h4>
                <p>
                  RedFlag Radar provides AI-powered contract analysis. The results provided are for informational purposes only and do NOT constitute legal advice. We are not a law firm, and our analysis should not replace the review of a qualified legal professional.
                </p>
              </section>

              <section className="space-y-3">
                <h4 className="text-white font-bold flex items-center gap-2">
                  <Lock className="w-4 h-4 text-primary" />
                  3. Data Privacy & Security
                </h4>
                <p>
                  We take your data privacy seriously. Contracts uploaded to our Service are processed securely. However, you are responsible for ensuring you have the right to upload any documents you submit for analysis.
                </p>
              </section>

              <section className="space-y-3">
                <h4 className="text-white font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-primary" />
                  4. Limitation of Liability
                </h4>
                <p>
                  RedFlag Radar shall not be liable for any damages arising from the use or inability to use the Service, including but not limited to reliance on the AI-generated analysis.
                </p>
              </section>

              <div className="p-4 rounded-2xl bg-primary/5 border border-primary/10 text-xs italic">
                Note: This is a demonstration application. In a production environment, these terms would be reviewed by legal counsel.
              </div>
            </div>

            <div className="p-6 border-t border-white/5 bg-zinc-900/50 backdrop-blur-md flex justify-end">
              <button
                onClick={onClose}
                className="px-8 py-3 rounded-xl bg-white text-black text-xs font-bold uppercase tracking-widest hover:bg-primary transition-all"
              >
                I Understand
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

import React from 'react';
import { ComparisonResult } from '../types';
import { motion } from 'motion/react';
import { Shield, AlertTriangle, CheckCircle2, XCircle, Scale, Info, Trophy } from 'lucide-react';
import { cn } from '../lib/utils';

interface ComparisonViewProps {
  result: ComparisonResult;
  onBack: () => void;
}

export const ComparisonView: React.FC<ComparisonViewProps> = ({ result, onBack }) => {
  return (
    <div className="max-w-6xl mx-auto space-y-12 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="px-6 py-2 rounded-xl bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-white hover:bg-white/10 transition-all"
        >
          Back to Audit
        </button>
        <div className="text-right">
          <h2 className="text-4xl font-hero tracking-tighter uppercase">Head-to-Head <span className="text-primary italic">Battle.</span></h2>
          <p className="text-sm text-white/30 font-light">{result.fileNameA} vs {result.fileNameB}</p>
        </div>
      </div>

      {/* Comparison Matrix */}
      <div className="rounded-[2.5rem] bg-white/[0.02] border border-white/5 overflow-hidden shadow-2xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-white/5 bg-white/[0.02]">
              <th className="p-8 text-[10px] font-bold uppercase tracking-widest text-white/20">Category</th>
              <th className="p-8 text-[10px] font-bold uppercase tracking-widest text-white/20">{result.fileNameA}</th>
              <th className="p-8 text-[10px] font-bold uppercase tracking-widest text-white/20">{result.fileNameB}</th>
            </tr>
          </thead>
          <tbody>
            {result.categories.map((cat, idx) => (
              <motion.tr
                key={cat.category}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="border-b border-white/5 hover:bg-white/[0.01] transition-colors"
              >
                <td className="p-8">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Scale className="w-4 h-4 text-primary" />
                    </div>
                    <span className="font-bold text-lg tracking-tight">{cat.category}</span>
                  </div>
                </td>
                <td className={cn(
                  "p-8 transition-all duration-500",
                  cat.contractA.isWinner ? "bg-green-500/5" : "bg-red-500/5"
                )}>
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      {cat.contractA.isWinner ? (
                        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-[8px] font-black uppercase tracking-tighter">
                          <CheckCircle2 className="w-2.5 h-2.5" /> Winner
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[8px] font-black uppercase tracking-tighter">
                          <XCircle className="w-2.5 h-2.5" /> Loser
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-white/60 leading-relaxed italic">"{cat.contractA.analysis}"</p>
                  </div>
                </td>
                <td className={cn(
                  "p-8 transition-all duration-500",
                  cat.contractB.isWinner ? "bg-green-500/5" : "bg-red-500/5"
                )}>
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      {cat.contractB.isWinner ? (
                        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-[8px] font-black uppercase tracking-tighter">
                          <CheckCircle2 className="w-2.5 h-2.5" /> Winner
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[8px] font-black uppercase tracking-tighter">
                          <XCircle className="w-2.5 h-2.5" /> Loser
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-white/60 leading-relaxed italic">"{cat.contractB.analysis}"</p>
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Verdict Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="relative p-12 rounded-[3rem] bg-gradient-to-br from-primary/20 via-white/[0.02] to-transparent border border-primary/30 shadow-[0_0_100px_rgba(242,125,38,0.1)] overflow-hidden"
      >
        <div className="absolute top-0 right-0 p-12 opacity-10">
          <Trophy className="w-48 h-48 text-primary" />
        </div>
        
        <div className="relative z-10 space-y-6 max-w-2xl">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-primary shadow-[0_0_20px_rgba(242,125,38,0.4)]">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <div>
              <h3 className="text-4xl font-hero tracking-tighter uppercase">The Neural <span className="text-primary italic">Verdict.</span></h3>
              <p className="text-xs font-bold uppercase tracking-[0.3em] text-white/30">Final Safety Determination</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="text-2xl font-bold tracking-tight">
              Safest Choice: <span className="text-primary underline underline-offset-8">
                {result.verdict.winner === 'A' ? result.fileNameA : result.verdict.winner === 'B' ? result.fileNameB : 'It\'s a Tie'}
              </span>
            </div>
            <p className="text-lg text-white/70 leading-relaxed font-light italic">
              {result.verdict.explanation}
            </p>
          </div>
        </div>

        {/* Decorative Corner */}
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-primary/10 blur-[80px] rounded-full" />
      </motion.div>
    </div>
  );
};

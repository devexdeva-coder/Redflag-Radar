import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export const CustomCursor: React.FC = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isPointer, setIsPointer] = useState(false);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const [isHoverDevice, setIsHoverDevice] = useState(false);

  useEffect(() => {
    setIsHoverDevice(window.matchMedia('(hover: hover) and (pointer: fine)').matches);

    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
      
      const target = e.target as HTMLElement;
      setIsPointer(
        window.getComputedStyle(target).cursor === 'pointer' ||
        target.tagName === 'BUTTON' ||
        target.tagName === 'A' ||
        target.closest('button') !== null ||
        target.closest('a') !== null
      );
    };

    const handleClick = (e: MouseEvent) => {
      const newRipple = {
        id: Date.now(),
        x: e.clientX,
        y: e.clientY,
      };
      setRipples((prev) => [...prev, newRipple]);
      setTimeout(() => {
        setRipples((prev) => prev.filter((r) => r.id !== newRipple.id));
      }, 1000);
    };

    const handleTouch = (e: TouchEvent) => {
      const touch = e.touches[0];
      const newRipple = {
        id: Date.now(),
        x: touch.clientX,
        y: touch.clientY,
      };
      setRipples((prev) => [...prev, newRipple]);
      setTimeout(() => {
        setRipples((prev) => prev.filter((r) => r.id !== newRipple.id));
      }, 1000);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleClick);
    window.addEventListener('touchstart', handleTouch);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleClick);
      window.removeEventListener('touchstart', handleTouch);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[9999] overflow-hidden">
      {/* Main Cursor (Only for hover devices) */}
      {isHoverDevice && (
        <>
          <motion.div
            className="fixed top-0 left-0 w-3 h-3 bg-primary rounded-full mix-blend-difference"
            animate={{
              x: mousePos.x - 6,
              y: mousePos.y - 6,
              scale: isPointer ? 3 : 1,
            }}
            transition={{ type: 'spring', damping: 30, stiffness: 300, mass: 0.4 }}
          />

          <motion.div
            className="fixed top-0 left-0 w-8 h-8 border border-primary/40 rounded-full"
            animate={{
              x: mousePos.x - 16,
              y: mousePos.y - 16,
              scale: isPointer ? 1.8 : 1,
              opacity: isPointer ? 0.4 : 1,
            }}
            transition={{ type: 'spring', damping: 25, stiffness: 200, mass: 0.6 }}
          />

          <motion.div
            className="fixed top-0 left-0 w-48 h-48 bg-primary/5 rounded-full blur-[80px]"
            animate={{
              x: mousePos.x - 96,
              y: mousePos.y - 96,
            }}
            transition={{ type: 'spring', damping: 40, stiffness: 100 }}
          />
        </>
      )}

      {/* Click Ripples (For both mouse and touch) */}
      <AnimatePresence>
        {ripples.map((ripple) => (
          <motion.div
            key={ripple.id}
            initial={{ opacity: 0.6, scale: 0 }}
            animate={{ opacity: 0, scale: 5 }}
            exit={{ opacity: 0 }}
            className="fixed top-0 left-0 w-12 h-12 border-2 border-primary/60 rounded-full"
            style={{
              left: ripple.x - 24,
              top: ripple.y - 24,
            }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        ))}
      </AnimatePresence>
    </div>
  );
};

import React from 'react';
import { motion } from 'motion/react';
import { ScanResult } from '@/src/types';
import { Clock, FileText, ChevronRight, Trash2, Calendar } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface HistoryViewProps {
  history: ScanResult[];
  onSelectItem: (item: ScanResult) => void;
  onDeleteItem: (id: string) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ history, onSelectItem, onDeleteItem }) => {
  const getRiskColor = (score: number) => {
    if (score < 30) return 'text-green-400';
    if (score < 60) return 'text-yellow-400';
    if (score < 85) return 'text-orange-400';
    return 'text-red-500';
  };

  const formatDate = (timestamp: number) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(timestamp));
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <Clock className="w-6 h-6 text-primary" />
          <h2 className="text-2xl font-bold text-white">Scan History</h2>
        </div>
        <p className="text-xs text-white/40 uppercase tracking-widest font-mono">
          {history.length} Total Scans
        </p>
      </div>

      {history.length === 0 ? (
        <div className="text-center py-20 border-2 border-dashed border-white/5 rounded-2xl">
          <FileText className="w-12 h-12 text-white/10 mx-auto mb-4" />
          <p className="text-white/40">No scans found in history.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {history.sort((a, b) => b.timestamp - a.timestamp).map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="group relative flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all cursor-pointer"
              onClick={() => onSelectItem(item)}
            >
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-white/5 group-hover:bg-primary/10 transition-colors">
                  <FileText className="w-5 h-5 text-white/40 group-hover:text-primary transition-colors" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white/90 group-hover:text-white transition-colors">
                    {item.fileName}
                  </h3>
                  <div className="flex items-center gap-3 mt-1">
                    <div className="flex items-center gap-1 text-[10px] text-white/30">
                      <Calendar className="w-3 h-3" />
                      {formatDate(item.timestamp)}
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-white/30">
                      <span className="w-1 h-1 rounded-full bg-white/20" />
                      {item.redFlags.length} Flags
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-[10px] uppercase tracking-widest font-bold text-white/20 mb-0.5">Risk Score</p>
                  <p className={cn("text-lg font-mono font-bold", getRiskColor(item.overallRiskScore))}>
                    {item.overallRiskScore}%
                  </p>
                </div>
                
                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteItem(item.id);
                    }}
                    className="p-2 rounded-lg text-white/20 hover:text-red-500 hover:bg-red-500/10 transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <ChevronRight className="w-5 h-5 text-white/10 group-hover:text-white/40 transition-colors" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};

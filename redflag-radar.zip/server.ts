import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // OpenRouter Proxy Endpoint
  app.post("/api/scan", async (req, res) => {
    const { text } = req.body;
    const apiKey = process.env.OPENROUTER_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ error: "OPENROUTER_API_KEY not configured in environment." });
    }

    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "HTTP-Referer": process.env.APP_URL || "http://localhost:3000",
          "X-Title": "RedFlag Radar",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "google/gemini-2.0-flash-001", // Using a fast model via OpenRouter
          messages: [
            {
              role: "system",
              content: "You are a legal contract analysis expert. You identify red flags, risks, and liabilities in contracts. Always return valid JSON."
            },
            {
              role: "user",
              content: `Analyze the following contract text for potential "red flags" (risks, unfair clauses, hidden liabilities). 
              Return the analysis in JSON format matching this structure:
              {
                "overallRiskScore": number (0-100),
                "summary": "brief executive summary",
                "redFlags": [
                  {
                    "title": "short title",
                    "description": "detailed explanation",
                    "severity": "low" | "medium" | "high" | "critical",
                    "score": number (0-100),
                    "clause": "the specific text from the contract",
                    "suggestion": "how to mitigate or renegotiate"
                  }
                ]
              }
              
              Contract Text:
              ${text.substring(0, 15000)}`
            }
          ],
          response_format: { type: "json_object" }
        })
      });

      if (!response.ok) {
        let errorData;
        const errorText = await response.text();
        try {
          errorData = JSON.parse(errorText);
        } catch (e) {
          errorData = { error: errorText || `OpenRouter returned status ${response.status}` };
        }
        console.error("OpenRouter Error:", errorData);
        return res.status(response.status).json(errorData);
      }

      const data = await response.json();
      let content = data.choices[0]?.message?.content || "";
      
      // Clean up markdown code blocks if present
      if (content.includes("```json")) {
        content = content.split("```json")[1].split("```")[0].trim();
      } else if (content.includes("```")) {
        content = content.split("```")[1].split("```")[0].trim();
      }
      
      if (!content) {
        throw new Error("Empty response from analysis engine.");
      }

      try {
        const result = JSON.parse(content);
        res.json(result);
      } catch (parseError) {
        console.error("JSON Parse Error:", parseError, "Content:", content);
        res.status(500).json({ error: "Analysis engine returned invalid data format." });
      }
    } catch (error: any) {
      console.error("Proxy Error:", error);
      res.status(500).json({ error: error.message || "Failed to process contract scanning." });
    }
  });

  // Comparison Endpoint
  app.post("/api/compare", async (req, res) => {
    const { textA, textB } = req.body;
    const apiKey = process.env.OPENROUTER_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ error: "OPENROUTER_API_KEY not configured." });
    }

    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "HTTP-Referer": process.env.APP_URL || "http://localhost:3000",
          "X-Title": "RedFlag Radar",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "google/gemini-2.0-flash-001",
          messages: [
            {
              role: "system",
              content: "You are a legal expert specializing in consumer protection. You perform head-to-head comparisons between two contracts. Always return valid JSON."
            },
            {
              role: "user",
              content: `Perform a head-to-head battle between Contract A and Contract B across key categories: Data Privacy, Hidden Fees, and Legal Rights.
              Determine which contract is more user-friendly in each category and provide an overall verdict.
              
              Return the analysis in JSON format matching this structure:
              {
                "categories": [
                  {
                    "category": "Data Privacy",
                    "contractA": { "analysis": "brief analysis of A", "isWinner": boolean },
                    "contractB": { "analysis": "brief analysis of B", "isWinner": boolean }
                  },
                  {
                    "category": "Hidden Fees",
                    "contractA": { "analysis": "brief analysis of A", "isWinner": boolean },
                    "contractB": { "analysis": "brief analysis of B", "isWinner": boolean }
                  },
                  {
                    "category": "Legal Rights",
                    "contractA": { "analysis": "brief analysis of A", "isWinner": boolean },
                    "contractB": { "analysis": "brief analysis of B", "isWinner": boolean }
                  }
                ],
                "verdict": {
                  "winner": "A" | "B" | "Tie",
                  "explanation": "detailed explanation of why one is safer"
                }
              }
              
              Contract A:
              ${textA.substring(0, 10000)}
              
              Contract B:
              ${textB.substring(0, 10000)}`
            }
          ],
          response_format: { type: "json_object" }
        })
      });

      if (!response.ok) {
        let errorData;
        const errorText = await response.text();
        try {
          errorData = JSON.parse(errorText);
        } catch (e) {
          errorData = { error: errorText || `OpenRouter returned status ${response.status}` };
        }
        return res.status(response.status).json(errorData);
      }

      const data = await response.json();
      let content = data.choices[0]?.message?.content || "";
      
      if (content.includes("```json")) {
        content = content.split("```json")[1].split("```")[0].trim();
      } else if (content.includes("```")) {
        content = content.split("```")[1].split("```")[0].trim();
      }
      
      const result = JSON.parse(content);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to compare contracts." });
    }
  });

  // Regenerate Summary Endpoint
  app.post("/api/regenerate-summary", async (req, res) => {
    const { redFlags, currentSummary } = req.body;
    const apiKey = process.env.OPENROUTER_API_KEY;

    if (!apiKey) {
      return res.status(500).json({ error: "OPENROUTER_API_KEY not configured." });
    }

    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "google/gemini-2.0-flash-001",
          messages: [
            {
              role: "system",
              content: "You are a legal expert. Provide a concise, high-impact executive summary of a contract based on the provided red flags. Focus on the most critical risks."
            },
            {
              role: "user",
              content: `Based on these detected red flags, provide a new, more detailed executive summary.
              
              Red Flags:
              ${JSON.stringify(redFlags)}
              
              Current Summary:
              ${currentSummary}
              
              Return ONLY the new summary text.`
            }
          ]
        })
      });

      const data = await response.json();
      res.json({ summary: data.choices[0].message.content });
    } catch (error) {
      res.status(500).json({ error: "Failed to regenerate summary." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
